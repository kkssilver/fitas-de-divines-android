# Fitas de Divines — projeto Android

Este projeto empacota o HTML original do jogo em um aplicativo Android usando WebView.
O arquivo do jogo está em `app/src/main/assets/index.html`; ele foi copiado sem reescrever
a lógica ou os recursos do jogo.

## Gerar o APK

1. Instale o Android Studio atual e o Android SDK Platform 35.
2. Abra a pasta `FitasDeDivines_Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Para testar: **Run > Run 'app'** com um dispositivo/emulador Android conectado.
5. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Notas

- O jogo é carregado de dentro do APK, portanto a parte principal funciona offline.
- `localStorage` e armazenamento DOM estão ativados para manter os salvamentos do jogo.
- A orientação do aparelho pode mudar entre retrato e paisagem.
- A permissão de internet é mantida para o modo de depuração opcional já presente no HTML
  (o carregamento do Eruda via CDN quando a URL contém `?debug`). O jogo normal não depende disso.
- O ambiente de criação usado para preparar este projeto não contém Android SDK/Gradle,
  então o APK binário não foi compilado aqui. O projeto está pronto para abrir e compilar no
  Android Studio.
